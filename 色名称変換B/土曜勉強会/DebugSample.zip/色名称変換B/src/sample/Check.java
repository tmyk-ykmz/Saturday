package sample;

public class Check {

	public static boolean checkColor(String colorName){
		if(colorName.equals("")){
			return true;
		}else{
			return false;
		}
	}

}